<html>	
  <body>	
    <?php	
     if ($_GET['run']){
     echo "Inside myfile.php:<br>";
     $output=null;
     $retval=null;
    // exec("uptime", $output, $retval);
    // echo "Returned with status $retval and output:<br>";
    // echo "The output was: $output[0]done";

    // $output=null;
    // $retval=null;
    
    echo "Running code myscript.sh ...... <br>"; 
    //exec("/var/www/html/myscript.sh", $output, $retval);
    exec("/usr/share/code/myscript.sh", $output, $retval);
    echo "Returned with status $retval and output:<br>";
    //echo "$output[0]<br>";
    
    echo "<br><br>output:<br>";    
    // Loop through outputarray array
    foreach($output as $value){
      echo $value . "<br>";
    }

    // echo "<br><br>retval:<br>";
    //foreach($retval as $value){
    //  echo $value . "<br>";
    //}
    }
    ?>
    
  </body>
</html>
