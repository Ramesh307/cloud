<html>
  <body>


<?php	    
   /* $_POST['fname']='Dan'; */
   if (isset($_POST['fname'])) {
    $fname = $_POST['fname'];

    // show the $name and $email
   echo "Thanks $fname for entering your name.<br>";
    } else {
    echo 'You need to provide your name';
    }

$vehicle1 = $_POST['vehicle1'];
$vehicle2 = $_POST['vehicle2'];
$vehicle3 = $_POST['vehicle3'];

echo "checkbox: $vehicle1 $vehicle2 $vehicle3<br>";


$favcolor = $_POST['favcolor'];
echo "color: $favcolor<br>";


$birthday = $_POST['birthday'];
echo "Birthday: $birthday<br>";


$age = $_POST['age'];
echo "Your age is: $age<br><br>";

$myint = $_POST['myint'];
echo "Number of ice cream cones: $myint<br><br>";

$fruit = $_POST['fruit'];
echo " the fruit I love is $fruit <br><br>";

exec("echo age:$age fruit:$fruit >> /data/abc.txt");

?>
   <a href="moreinputs.html"> Go back to the previous page</a><br>
  </body>
</html>
