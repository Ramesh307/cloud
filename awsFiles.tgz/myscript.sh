#!/bin/bash
echo "path= $PATH<br><br>"
echo "`env`<br><br>"
echo "testing .... but now it works" >> /data/abc.txt
