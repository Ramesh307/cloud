<html>
  <body>


<?php	    
   /* $_POST['fname']='Dan'; */
   if (isset($_POST['fname'])) {
    $fname = $_POST['fname'];

    // show the $name and $email
   echo "Thanks $fname for entering your name.<br>";
    } else {
    echo 'You need to provide your name';
    }
?>
  </body>
</html>
