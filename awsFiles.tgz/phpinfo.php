<?php phpinfo( ); ?>
